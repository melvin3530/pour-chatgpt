# Changements de cette version (nouvelle interface)

Basé sur Fortnite-ChestCounter de LED-N (licence MIT, voir LICENSE). Seul l'aspect a été retravaillé :
le comptage des coffres, la lecture des replays et la sécurité n'ont pas changé.

- **Overlay** (NativeOverlay.cs) : palette violet profond, barre dégradée or-orange en haut,
  icône de coffre dessinée, lignes de détail sur des pastilles arrondies.
- **Rapport** (ReportWriter.cs) : cartes arrondies avec ombre, grand compteur en dégradé,
  graphique à barres dégradées, titres avec liseré, survol des lignes. Thème clair et sombre.
- **Page overlay pour OBS** : mêmes couleurs que l'overlay, liseré dégradé.
- **Console** (ConsoleUi.cs) : bandeau arrondi, flèche de menu ▶, options non sélectionnées en gris clair.
- **Mises à jour** (Models.cs) : désactivées par défaut. Sinon le programme pourrait remplacer
  cette version par l'originale. Si ton ancien config.json les a activées, mets-les sur « off » (touche C).

Pour fabriquer l'exe : installer le SDK .NET 10 puis double-cliquer sur build.bat.
